# Triangle Solver
Current;y can only do pythagorean theorem
will add law of sin/cos functionality

